import 'package:flutter/material.dart';
import '../../services/api_service.dart';
import '../../services/whatsapp_service.dart';
import '../auth/login_screen.dart';

class RiderMissionScreen extends StatefulWidget {
  const RiderMissionScreen({super.key});

  @override
  State<RiderMissionScreen> createState() => _RiderMissionScreenState();
}

class _RiderMissionScreenState extends State<RiderMissionScreen> {
  Map<String, dynamic> _wallet = {'balance': 0.0};
  Map<String, dynamic>? _activeMission;
  bool _isLoading = true;

  @override
  void initState() {
    super.initState();
    _loadRiderData();
  }

  Future<void> _loadRiderData() async {
    setState(() => _isLoading = true);
    try {
      final wRes = await ApiService.get('/api/finance/wallet/me');
      final mRes = await ApiService.get('/api/riders/active-mission');
      setState(() {
        _wallet = wRes['wallet'] ?? {'balance': 0.0};
        _activeMission = mRes['mission'];
      });
    } catch (_) {}
    setState(() => _isLoading = false);
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: const Text('Rider Dispatch Mission'),
        actions: [
          IconButton(
            icon: const Icon(Icons.logout),
            onPressed: () async {
              await ApiService.logout();
              if (!mounted) return;
              // ignore: use_build_context_synchronously
              Navigator.pushReplacement(context, MaterialPageRoute(builder: (_) => const LoginScreen()));
            },
          ),
        ],
      ),
      body: _isLoading
          ? const Center(child: CircularProgressIndicator())
          : RefreshIndicator(
              onRefresh: _loadRiderData,
              child: SingleChildScrollView(
                padding: const EdgeInsets.all(16.0),
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    // Rider Earnings Card
                    Container(
                      padding: const EdgeInsets.all(16),
                      decoration: BoxDecoration(
                        gradient: const LinearGradient(colors: [Color(0xFF2B0008), Color(0xFF7F1D1D)]),
                        borderRadius: BorderRadius.circular(16),
                      ),
                      child: Column(
                        crossAxisAlignment: CrossAxisAlignment.start,
                        children: [
                          const Text('Trip Earnings Balance', style: TextStyle(color: Colors.white70, fontSize: 12)),
                          Text('₦${(_wallet['balance'] as num?)?.toStringAsFixed(2) ?? '0.00'}',
                              style: const TextStyle(color: Colors.white, fontSize: 26, fontWeight: FontWeight.bold)),
                          const SizedBox(height: 12),
                          ElevatedButton.icon(
                            style: ElevatedButton.styleFrom(backgroundColor: Colors.white, foregroundColor: const Color(0xFF7F1D1D)),
                            icon: const Icon(Icons.account_balance),
                            label: const Text('Withdraw Earnings to Bank'),
                            onPressed: () {},
                          ),
                        ],
                      ),
                    ),
                    const SizedBox(height: 20),

                    // Active Delivery Mission Card
                    const Text('Active Dispatch Mission 🛵', style: TextStyle(fontSize: 16, fontWeight: FontWeight.bold)),
                    const SizedBox(height: 10),
                    if (_activeMission == null)
                      const Card(
                        child: Padding(
                          padding: EdgeInsets.all(24.0),
                          child: Center(
                            child: Column(
                              children: [
                                Icon(Icons.two_wheeler, size: 48, color: Colors.grey),
                                SizedBox(height: 8),
                                Text('You are online. Waiting for next dispatch mission...', style: TextStyle(color: Colors.grey)),
                              ],
                            ),
                          ),
                        ),
                      )
                    else
                      Card(
                        shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(16)),
                        elevation: 4,
                        child: Padding(
                          padding: const EdgeInsets.all(16.0),
                          child: Column(
                            crossAxisAlignment: CrossAxisAlignment.start,
                            children: [
                              Row(
                                mainAxisAlignment: MainAxisAlignment.spaceBetween,
                                children: [
                                  Text('Ref: ${_activeMission!['order_ref']}', style: const TextStyle(fontWeight: FontWeight.bold)),
                                  Chip(label: Text('${_activeMission!['status']}', style: const TextStyle(fontSize: 11))),
                                ],
                              ),
                              const Divider(),
                              Text('📍 Dropoff: ${_activeMission!['delivery_address']}'),
                              Text('👤 Customer: ${_activeMission!['customer_name']}'),
                              const SizedBox(height: 12),
                              Row(
                                children: [
                                  Expanded(
                                    child: ElevatedButton.icon(
                                      style: ElevatedButton.styleFrom(backgroundColor: const Color(0xFF25D366)),
                                      icon: const Icon(Icons.chat),
                                      label: const Text('WhatsApp Customer'),
                                      onPressed: () {
                                        WhatsAppService.openWhatsApp(
                                          phone: _activeMission!['delivery_phone'] ?? '',
                                          message: "Hello, I am your RushPoint courier delivering order ${_activeMission!['order_ref']}.",
                                        );
                                      },
                                    ),
                                  ),
                                ],
                              ),
                            ],
                          ),
                        ),
                      ),
                  ],
                ),
              ),
            ),
    );
  }
}
