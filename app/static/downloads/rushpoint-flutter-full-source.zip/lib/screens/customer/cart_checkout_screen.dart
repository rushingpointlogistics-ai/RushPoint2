import 'package:flutter/material.dart';
import '../../services/api_service.dart';
import '../../services/whatsapp_service.dart';

class CartCheckoutScreen extends StatefulWidget {
  final Map<String, dynamic> store;
  final List<Map<String, dynamic>> items;

  const CartCheckoutScreen({super.key, required this.store, required this.items});

  @override
  State<CartCheckoutScreen> createState() => _CartCheckoutScreenState();
}

class _CartCheckoutScreenState extends State<CartCheckoutScreen> {
  final _addressController = TextEditingController(text: "Katsina City Hub");
  final _phoneController = TextEditingController(text: "+2348000000000");
  final _promoController = TextEditingController();

  double _subtotal = 0.0;
  double _deliveryFee = 1200.0;
  double _discount = 0.0;
  // ignore: prefer_final_fields
  double _platformFee = 150.0;
  double _total = 0.0;

  // ignore: prefer_final_fields
  double _customerLat = 12.9908;
  // ignore: prefer_final_fields
  double _customerLon = 7.6018;
  double _distanceKm = 1.8;
  int _estimatedMinutes = 12;
  String _routingEngine = "OSRM_ROAD_ROUTER";

  bool _isCalculatingRoute = false;
  bool _isPlacingOrder = false;
  String? _promoMessage;

  @override
  void initState() {
    super.initState();
    _calculateSubtotal();
    _fetchRoadDistanceQuote();
  }

  void _calculateSubtotal() {
    double sum = 0.0;
    for (var item in widget.items) {
      final price = (item['price'] as num?)?.toDouble() ?? 0.0;
      final qty = (item['quantity'] as num?)?.toInt() ?? 1;
      sum += price * qty;
    }
    _subtotal = sum;
    _updateTotal();
  }

  void _updateTotal() {
    _total = (_subtotal - _discount) + _deliveryFee + _platformFee;
    if (_total < 0) _total = 0.0;
  }

  Future<void> _fetchRoadDistanceQuote() async {
    setState(() => _isCalculatingRoute = true);
    try {
      final res = await ApiService.post('/api/marketplace/calculate-delivery-quote', {
        'store_id': widget.store['id'],
        'customer_lat': _customerLat,
        'customer_lon': _customerLon,
        'cargo_weight_kg': 2.0,
      });

      if (res['success'] == true && res['routing'] != null) {
        final r = res['routing'];
        setState(() {
          _distanceKm = (r['distance_km'] as num?)?.toDouble() ?? 1.8;
          _estimatedMinutes = (r['estimated_duration_minutes'] as num?)?.toInt() ?? 15;
          _routingEngine = r['engine'] ?? 'OSRM_ROAD_ROUTER';
          final pricing = r['pricing'] ?? {};
          _deliveryFee = (pricing['total_delivery_fee'] as num?)?.toDouble() ?? 1200.0;
          _updateTotal();
        });
      }
    } catch (_) {}
    setState(() => _isCalculatingRoute = false);
  }

  Future<void> _applyPromo() async {
    final code = _promoController.text.trim();
    if (code.isEmpty) return;

    try {
      final res = await ApiService.post('/api/promos/apply', {
        'promo_code_or_id': code,
        'store_id': widget.store['id'],
        'subtotal': _subtotal,
        'delivery_fee': _deliveryFee,
      });

      if (res['success'] == true) {
        setState(() {
          _discount = (res['discount_applied'] as num?)?.toDouble() ?? 0.0;
          _deliveryFee = (res['final_delivery_fee'] as num?)?.toDouble() ?? _deliveryFee;
          _promoMessage = res['message'];
          _updateTotal();
        });
      } else {
        if (!mounted) return;
        ScaffoldMessenger.of(context).showSnackBar(SnackBar(content: Text(res['detail'] ?? 'Invalid promo code.')));
      }
    } catch (e) {
      if (!mounted) return;
      ScaffoldMessenger.of(context).showSnackBar(const SnackBar(content: Text('Failed to apply promo code.')));
    }
  }

  Future<void> _placeOrder() async {
    setState(() => _isPlacingOrder = true);
    try {
      final payload = {
        'store_id': widget.store['id'],
        'delivery_address': _addressController.text.trim(),
        'delivery_phone': _phoneController.text.trim(),
        'payment_method': 'WALLET',
        'items': widget.items.map((i) => {
          'product_id': i['id'],
          'quantity': i['quantity'] ?? 1,
        }).toList(),
      };

      final res = await ApiService.post('/api/marketplace/orders', payload);

      if (res['success'] == true) {
        final orderRef = res['order_ref'] ?? 'RP-ORD';
        if (!mounted) return;
        showDialog(
          context: context,
          barrierDismissible: false,
          builder: (ctx) => AlertDialog(
            shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(20)),
            title: const Text('🎉 Order Placed Successfully!'),
            content: Column(
              mainAxisSize: MainAxisSize.min,
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Text('Order Ref: $orderRef', style: const TextStyle(fontWeight: FontWeight.bold)),
                const SizedBox(height: 8),
                Text('Your 4-digit Delivery PIN is: ${res['pod_otp'] ?? '----'}', style: const TextStyle(fontSize: 16, color: Color(0xFF7F1D1D), fontWeight: FontWeight.bold)),
                const SizedBox(height: 12),
                const Text('Funds are held safely in escrow until you provide the PIN to your rider upon arrival.'),
              ],
            ),
            actions: [
              TextButton.icon(
                icon: const Icon(Icons.chat, color: Color(0xFF25D366)),
                label: const Text('Share on WhatsApp'),
                onPressed: () {
                  WhatsAppService.shareOrderStatus(
                    orderRef: orderRef,
                    status: 'Preparing Order at Store',
                    customerPhone: _phoneController.text.trim(),
                  );
                },
              ),
              ElevatedButton(
                onPressed: () {
                  Navigator.pop(ctx);
                  Navigator.pop(context);
                },
                child: const Text('Back to Home'),
              ),
            ],
          ),
        );
      } else {
        if (!mounted) return;
        ScaffoldMessenger.of(context).showSnackBar(SnackBar(content: Text(res['detail'] ?? 'Order failed.')));
      }
    } catch (e) {
      if (!mounted) return;
      ScaffoldMessenger.of(context).showSnackBar(const SnackBar(content: Text('Network error. Check wallet balance.')));
    } finally {
      setState(() => _isPlacingOrder = false);
    }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: const Text('Secure Checkout 🔒')),
      body: SingleChildScrollView(
        padding: const EdgeInsets.all(16.0),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            // Store details
            Card(
              child: ListTile(
                leading: const CircleAvatar(backgroundColor: Color(0xFF7F1D1D), child: Icon(Icons.store, color: Colors.white)),
                title: Text(widget.store['store_name'] ?? 'Store', style: const TextStyle(fontWeight: FontWeight.bold)),
                subtitle: Text('Category: ${widget.store['category'] ?? 'Retail'}'),
              ),
            ),
            const SizedBox(height: 16),

            // Live Road Routing Map Card
            Container(
              padding: const EdgeInsets.all(14),
              decoration: BoxDecoration(
                color: const Color(0xFF0F172A),
                borderRadius: BorderRadius.circular(16),
              ),
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  const Row(
                    mainAxisAlignment: MainAxisAlignment.spaceBetween,
                    children: [
                      Text('🗺️ Multi-Engine Road Routing', style: TextStyle(color: Colors.white, fontWeight: FontWeight.bold)),
                      Chip(label: Text('Live GPS', style: TextStyle(fontSize: 10, color: Colors.white)), backgroundColor: Colors.red),
                    ],
                  ),
                  const SizedBox(height: 8),
                  if (_isCalculatingRoute)
                    const LinearProgressIndicator(color: Color(0xFFEF4444))
                  else
                    Row(
                      mainAxisAlignment: MainAxisAlignment.spaceAround,
                      children: [
                        Column(
                          children: [
                            const Text('Driving Distance', style: TextStyle(color: Colors.white70, fontSize: 11)),
                            Text('${_distanceKm.toStringAsFixed(2)} km', style: const TextStyle(color: Colors.white, fontSize: 18, fontWeight: FontWeight.bold)),
                          ],
                        ),
                        Column(
                          children: [
                            const Text('Est. Arrival', style: TextStyle(color: Colors.white70, fontSize: 11)),
                            Text('$_estimatedMinutes mins', style: const TextStyle(color: Color(0xFFFECDD3), fontSize: 18, fontWeight: FontWeight.bold)),
                          ],
                        ),
                        Column(
                          children: [
                            const Text('Router', style: TextStyle(color: Colors.white70, fontSize: 11)),
                            Text(_routingEngine == 'OSRM_ROAD_ROUTER' ? 'OSRM Live' : 'Haversine', style: const TextStyle(color: Colors.greenAccent, fontSize: 14, fontWeight: FontWeight.bold)),
                          ],
                        ),
                      ],
                    ),
                ],
              ),
            ),
            const SizedBox(height: 16),

            // Delivery Details Form
            const Text('Delivery Location', style: TextStyle(fontWeight: FontWeight.bold, fontSize: 15)),
            const SizedBox(height: 8),
            TextField(
              controller: _addressController,
              decoration: const InputDecoration(
                labelText: 'Street Address / Destination Landmark',
                prefixIcon: Icon(Icons.location_on),
                border: OutlineInputBorder(),
              ),
            ),
            const SizedBox(height: 12),
            TextField(
              controller: _phoneController,
              decoration: const InputDecoration(
                labelText: 'Contact Phone Number',
                prefixIcon: Icon(Icons.phone),
                border: OutlineInputBorder(),
              ),
            ),
            const SizedBox(height: 16),

            // Temu-Style Promo Code Input
            const Text('Promo Code / Flash Discount ⚡', style: TextStyle(fontWeight: FontWeight.bold, fontSize: 15)),
            const SizedBox(height: 8),
            Row(
              children: [
                Expanded(
                  child: TextField(
                    controller: _promoController,
                    decoration: const InputDecoration(
                      hintText: 'e.g. FLASH20, FREESHIP',
                      border: OutlineInputBorder(),
                    ),
                  ),
                ),
                const SizedBox(width: 8),
                ElevatedButton(
                  onPressed: _applyPromo,
                  child: const Text('Apply'),
                ),
              ],
            ),
            if (_promoMessage != null)
              Padding(
                padding: const EdgeInsets.only(top: 6),
                child: Text(_promoMessage!, style: const TextStyle(color: Colors.green, fontWeight: FontWeight.bold, fontSize: 12)),
              ),
            const SizedBox(height: 20),

            // Cost Summary Card
            Container(
              padding: const EdgeInsets.all(16),
              decoration: BoxDecoration(color: Colors.white, borderRadius: BorderRadius.circular(16), border: Border.all(color: Colors.grey.shade200)),
              child: Column(
                children: [
                  Row(mainAxisAlignment: MainAxisAlignment.spaceBetween, children: [const Text('Items Subtotal:'), Text('₦${_subtotal.toStringAsFixed(2)}')]),
                  const SizedBox(height: 6),
                  Row(mainAxisAlignment: MainAxisAlignment.spaceBetween, children: [Text('Road Delivery Fee (${_distanceKm.toStringAsFixed(1)}km):'), Text('₦${_deliveryFee.toStringAsFixed(2)}')]),
                  if (_discount > 0) ...[
                    const SizedBox(height: 6),
                    Row(mainAxisAlignment: MainAxisAlignment.spaceBetween, children: [const Text('Promo Discount:', style: TextStyle(color: Colors.green)), Text('-₦${_discount.toStringAsFixed(2)}', style: const TextStyle(color: Colors.green, fontWeight: FontWeight.bold))]),
                  ],
                  const SizedBox(height: 6),
                  Row(mainAxisAlignment: MainAxisAlignment.spaceBetween, children: [const Text('Escrow Protection Fee:'), Text('₦${_platformFee.toStringAsFixed(2)}')]),
                  const Divider(height: 20),
                  Row(mainAxisAlignment: MainAxisAlignment.spaceBetween, children: [
                    const Text('Total Amount:', style: TextStyle(fontSize: 16, fontWeight: FontWeight.bold)),
                    Text('₦${_total.toStringAsFixed(2)}', style: const TextStyle(fontSize: 20, fontWeight: FontWeight.bold, color: Color(0xFF7F1D1D))),
                  ]),
                ],
              ),
            ),
            const SizedBox(height: 24),

            // Checkout Button
            ElevatedButton(
              onPressed: _isPlacingOrder ? null : _placeOrder,
              child: _isPlacingOrder ? const CircularProgressIndicator(color: Colors.white) : Text('Pay ₦${_total.toStringAsFixed(2)} via Wallet & Place Order 🚀'),
            ),
          ],
        ),
      ),
    );
  }
}
